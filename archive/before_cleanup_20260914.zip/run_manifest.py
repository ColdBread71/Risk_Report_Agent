"""Versioned run manifests and checked-upstream selection for Node [0]-[2]."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


MANIFEST_SCHEMA_VERSION = "node_run_manifest.v1"
REGISTRY_SCHEMA_VERSION = "checked_upstream_registry.v1"

_STAGE_FILES = {
    "0": "progress/node_0_scope.json",
    "1": "progress/node_1_context.json",
    "2": "progress/node_2_assets.json",
}


def _now() -> str:
    return datetime.now(UTC).isoformat()


def _atomic_write(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def initialize_run_manifest(
    *,
    run_directory: Path,
    run_id: str,
    project_id: str,
    evidence_packet_ref: dict[str, Any],
    text_model: str,
    requested_node: str,
    rule_versions: dict[str, str],
    upstream: dict[str, Any] | None = None,
) -> Path:
    """Create the immutable run identity before executing a business node."""
    path = run_directory / "run_manifest.json"
    if path.exists() or (run_directory.exists() and any(run_directory.iterdir())):
        raise ValueError(f"Run manifest already exists; choose a new run-id: {path}")
    created_at = _now()
    payload = {
        "schema_version": MANIFEST_SCHEMA_VERSION,
        "run_id": run_id,
        "project_id": project_id,
        "created_at": created_at,
        "updated_at": created_at,
        "requested_node": requested_node,
        "evidence_packet_ref": evidence_packet_ref,
        "text_model": text_model,
        "rule_versions": rule_versions,
        "upstream": upstream or {},
        "nodes": {},
    }
    _atomic_write(path, payload)
    return path


def record_node_result(
    *,
    run_directory: Path,
    node_id: str,
    status: str,
    completed_node: str,
) -> Path:
    """Record one generated node artifact without marking it business-checked."""
    manifest_path = run_directory / "run_manifest.json"
    payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    stage_json = _STAGE_FILES[node_id]
    stage_excel = stage_json.removesuffix(".json") + ".xlsx"
    if status in {"node_0_completed", "node_1_completed", "asset_identification_completed"}:
        if not all((run_directory / name).is_file() for name in (stage_json, stage_excel)):
            raise ValueError("Completed node is missing its JSON or Excel artifact")
    payload["nodes"][f"node_{node_id}"] = {
        "status": status,
        "completed_node": completed_node,
        "generated_at": _now(),
        "output_json": stage_json,
        "output_excel": stage_excel,
        "checked_usable": False,
        "checked_at": None,
    }
    payload["updated_at"] = _now()
    _atomic_write(manifest_path, payload)
    return manifest_path


def _registry_path(project_output_directory: Path) -> Path:
    return project_output_directory / "checked_upstreams.json"


def mark_node_checked(
    *,
    project_output_directory: Path,
    run_id: str,
    node_id: str,
) -> tuple[Path, Path]:
    """Mark a reviewed node usable and invalidate checked downstream pointers."""
    run_directory = project_output_directory / run_id
    manifest_path = run_directory / "run_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    node_key = f"node_{node_id}"
    node_record = manifest.get("nodes", {}).get(node_key)
    if node_record is None:
        raise ValueError(f"Run {run_id} has no generated {node_key} output")
    expected_status = {"0": "node_0_completed", "1": "node_1_completed", "2": "asset_identification_completed"}[node_id]
    if node_record.get("status") != expected_status:
        raise ValueError("An incomplete or failed node cannot be marked checked usable")
    output_json = run_directory / node_record["output_json"]
    output_excel = run_directory / node_record["output_excel"]
    if not output_json.is_file() or not output_excel.is_file():
        raise ValueError(f"Run {run_id} is missing the JSON or Excel artifact for {node_key}")

    registry_path = _registry_path(project_output_directory)
    if registry_path.is_file():
        registry = json.loads(registry_path.read_text(encoding="utf-8"))
    else:
        registry = {
            "schema_version": REGISTRY_SCHEMA_VERSION,
            "project_id": manifest["project_id"],
            "updated_at": _now(),
            "nodes": {},
        }

    required_upstream = {"1": "node_0", "2": "node_1"}.get(node_id)
    if required_upstream is not None:
        expected = registry.get("nodes", {}).get(required_upstream)
        actual = manifest.get("upstream", {}).get(required_upstream)
        if expected is None or expected.get("requires_revalidation"):
            raise ValueError(f"No currently checked usable {required_upstream} is registered")
        if actual is None or actual.get("run_id") != expected.get("run_id"):
            raise ValueError(
                f"{node_key} was not generated from the currently checked {required_upstream}"
            )

    checked_at = _now()
    node_record["checked_usable"] = True
    node_record["checked_at"] = checked_at
    manifest["updated_at"] = checked_at
    _atomic_write(manifest_path, manifest)

    registry.setdefault("nodes", {})[node_key] = {
        "run_id": run_id,
        "manifest": f"{run_id}/run_manifest.json",
        "output_json": f"{run_id}/{node_record['output_json']}",
        "output_excel": f"{run_id}/{node_record['output_excel']}",
        "checked_at": checked_at,
        "checked_usable": True,
        "requires_revalidation": False,
    }
    for downstream_id in range(int(node_id) + 1, 3):
        downstream_key = f"node_{downstream_id}"
        previous = registry["nodes"].get(downstream_key)
        if previous is not None:
            previous["checked_usable"] = False
            previous["requires_revalidation"] = True
            previous["invalidated_by"] = {"node_id": node_key, "run_id": run_id}
    registry["updated_at"] = checked_at
    _atomic_write(registry_path, registry)
    return manifest_path, registry_path


def load_checked_upstream(
    *,
    project_output_directory: Path,
    upstream_node_id: str,
    expected_packet_sha256: str,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Load the latest explicitly checked upstream snapshot, never a latest-named file."""
    registry_path = _registry_path(project_output_directory)
    if not registry_path.is_file():
        raise ValueError(f"No checked upstream registry exists: {registry_path}")
    registry = json.loads(registry_path.read_text(encoding="utf-8"))
    node_key = f"node_{upstream_node_id}"
    pointer = registry.get("nodes", {}).get(node_key)
    if (
        pointer is None
        or not pointer.get("checked_usable")
        or pointer.get("requires_revalidation")
    ):
        raise ValueError(f"No checked usable {node_key} output is registered")
    snapshot_path = project_output_directory / pointer["output_json"]
    snapshot = json.loads(snapshot_path.read_text(encoding="utf-8"))
    state = snapshot.get("state", {})
    packet_ref = state.get("evidence_packet_ref") or {}
    if packet_ref.get("packet_sha256") != expected_packet_sha256:
        raise ValueError("Checked upstream evidence packet does not match this run")
    return state, {
        "run_id": pointer["run_id"],
        "output_json": pointer["output_json"],
        "checked_at": pointer["checked_at"],
    }


__all__ = [
    "initialize_run_manifest",
    "load_checked_upstream",
    "mark_node_checked",
    "record_node_result",
]
