"""Command-line entry point for the Node [0]-[3] workflow slice."""

from __future__ import annotations

import argparse
import os
import re
from pathlib import Path
from typing import Sequence
from uuid import uuid4

from langgraph.types import Command

from core.exporter import export_asset_review, export_tara_report, export_workflow_progress
from core.logger import setup_logger
from core.run_manifest import (
    initialize_run_manifest,
    load_checked_upstream,
    record_node_result,
)
from core.workflow import node0_graph, node1_graph, node2_graph, tara_graph
from nodes.context_builder import SCOPE_RULE_VERSION
from nodes.field_extractor import FIELD_FACT_PROMPT_VERSION
from schemas.legal import ScopeStatement
from schemas.methodology import RiskMethodology
from schemas.product import ProductContext
from schemas.risk import RiskAcceptanceCriteria
from schemas.run_input import EvidencePacketRef
from tools.evidence_input import load_evidence_packet
from tools.retrieval_profiles import PROFILE_VERSION


logger = setup_logger("main")
PROJECT_ROOT = Path(__file__).resolve().parent


def _build_parser() -> argparse.ArgumentParser:
    """Define explicit inputs and execution boundaries for one workflow run."""
    parser = argparse.ArgumentParser(description="Run the CRA/TARA workflow.")
    parser.add_argument(
        "--mode",
        choices=("assets", "full"),
        default="assets",
        help="assets stops at Node [2]; full may continue to Node [3] after approval.",
    )
    parser.add_argument(
        "--node",
        choices=("0", "1", "2"),
        help=(
            "Run only one business node. Node 1/2 automatically use the last explicitly "
            "checked usable upstream snapshot for the same evidence packet."
        ),
    )
    parser.add_argument(
        "--evidence-packet",
        required=True,
        help="Path to a validated evidence-packet JSON file.",
    )
    parser.add_argument(
        "--workspace",
        default=str(PROJECT_ROOT),
        help="Workspace used to resolve packet, manifest, and source paths.",
    )
    parser.add_argument(
        "--output-dir",
        default=str(PROJECT_ROOT / "output"),
        help="Base directory for run-specific outputs.",
    )
    parser.add_argument(
        "--run-id",
        help="Run ID; single-node runs require a new ID and never overwrite an existing run.",
    )
    parser.add_argument(
        "--rag-index",
        help=(
            "Optional persisted FAISS index directory. When supplied, Node [0]-[2] "
            "use field retrieval and partial fact extraction instead of the full packet prompt."
        ),
    )
    return parser


def _resume_asset_review(result: dict, config: dict) -> dict:
    """Collect the mandatory step [2] asset decision in the full CLI mode."""
    interrupts = result.get("__interrupt__", [])
    if not interrupts:
        return result

    assets = result.get("assets", [])
    logger.info("Node [2] 等待人工确认，共 %d 项资产", len(assets))
    asset_assessment = result.get("asset_assessment")
    assessment_text = getattr(asset_assessment, "value", asset_assessment)
    logger.info("资产识别评估: %s", assessment_text)
    logger.info("资产识别说明: %s", result.get("asset_notes") or "无")
    for asset in assets:
        logger.info(
            "待确认资产 %s: %s | 类型=%s | 位置=%s | 价值=%s",
            asset.asset_id,
            asset.name,
            asset.asset_type,
            asset.location or "未知",
            asset.value or "未知",
        )
        logger.info("资产描述: %s", asset.description)
        for objective in asset.related_objectives:
            logger.info(
                "  目标 %s [%s]: %s",
                objective.objective_id,
                objective.category,
                objective.description,
            )

    try:
        answer = input(
            "Type APPROVE to confirm the complete Node [2] asset inventory: "
        ).strip()
        approved = answer == "APPROVE"
        notes = input("Review notes (optional): ").strip() or None
    except EOFError:
        logger.warning("当前终端不可交互；工作流保持在 Node [2] 人工确认点")
        return result

    return tara_graph.invoke(
        Command(resume={"approved": approved, "notes": notes}),
        config=config,
    )


def _log_result(result: dict) -> None:
    """Log a compact summary without serializing source material."""
    logger.info("当前状态: %s", result.get("status"))
    for error in result.get("errors", []):
        logger.error("捕获到的错误: %s", error)

    scope = result.get("scope")
    product_context = result.get("product_context")
    logger.info("Node 0 Scope 产品名: %s", scope.product_name if scope else None)
    logger.info("Node 1 Context 产品名: %s", product_context.product_name if product_context else None)
    logger.info("Node 2 识别资产数: %d", len(result.get("assets", [])))
    threat_assessment = result.get("threat_assessment")
    logger.info("Node 3 识别威胁数: %d", len(threat_assessment.threats) if threat_assessment else 0)


def _run_with_progress(
    graph,
    initial_state: dict,
    config: dict,
    run_output_dir: Path,
    run_id: str,
) -> dict:
    """Stream graph updates and persist every completed or failed business node."""
    result: dict = dict(initial_state)
    result.setdefault("errors", [])
    interrupts = []
    for update in graph.stream(initial_state, config=config, stream_mode="updates"):
        if "__interrupt__" in update:
            interrupts = update["__interrupt__"]
            completed_node = None
        else:
            completed_node = next(iter(update), None)
            node_update = update.get(completed_node, {}) if completed_node else {}
            if isinstance(node_update, dict):
                result.update(node_update)
        if interrupts:
            result["__interrupt__"] = interrupts
        try:
            export_workflow_progress(result, run_output_dir, run_id, completed_node)
        except Exception as exc:
            logger.exception(
                "进度 Excel/快照写入失败，但工作流继续执行；请确认输出文件未被占用: %s",
                exc,
            )
    return result


def _single_node_input(
    *,
    node_id: str,
    project_output_dir: Path,
    packet_sha256: str,
) -> tuple[dict, dict]:
    """Build a typed state input from the checked upstream registry."""
    if node_id == "0":
        return {"errors": []}, {}

    upstream_id = "0" if node_id == "1" else "1"
    raw, pointer = load_checked_upstream(
        project_output_directory=project_output_dir,
        upstream_node_id=upstream_id,
        expected_packet_sha256=packet_sha256,
    )
    state = {
        "errors": list(raw.get("errors", [])),
        "evidence_packet_ref": EvidencePacketRef.model_validate(raw["evidence_packet_ref"]),
        "scope": ScopeStatement.model_validate(raw["scope"]),
    }
    if node_id == "2":
        state.update(
            {
                "product_context": ProductContext.model_validate(raw["product_context"]),
                "risk_methodology": RiskMethodology.model_validate(raw["risk_methodology"]),
                "risk_acceptance_criteria": RiskAcceptanceCriteria.model_validate(
                    raw["risk_acceptance_criteria"]
                ),
            }
        )
    return state, {f"node_{upstream_id}": pointer}


def _configured_text_model() -> str:
    return os.getenv(
        "DASHSCOPE_TEXT_MODEL",
        os.getenv("DASHSCOPE_MODEL", os.getenv("OPENAI_MODEL", "qwen-max")),
    )


def main(argv: Sequence[str] | None = None) -> int:
    """Run to the selected boundary and export only validated results."""
    args = _build_parser().parse_args(argv)
    run_id = args.run_id or uuid4().hex
    if re.fullmatch(r"[A-Za-z0-9_-]{1,64}", run_id) is None:
        logger.error("run_id 只能包含字母、数字、下划线和连字符，最长 64 字符")
        return 1
    workspace = Path(args.workspace).resolve()
    try:
        evidence_binding = load_evidence_packet(
            args.evidence_packet,
            workspace=workspace,
            verify_source_files=True,
        )
    except Exception as exc:
        logger.error("证据包加载失败: %s", exc)
        return 1
    run_output_dir = Path(args.output_dir).resolve() / evidence_binding.packet.project_id / run_id
    config = {
        "configurable": {
            "thread_id": run_id,
            "evidence_packet_path": args.evidence_packet,
            "workspace": str(workspace),
            "field_checkpoint_dir": str(run_output_dir / "progress" / "field_facts"),
        }
    }
    if args.rag_index:
        config["configurable"]["rag_index_dir"] = str(Path(args.rag_index).resolve())

    if args.node is not None:
        project_output_dir = Path(args.output_dir).resolve() / evidence_binding.packet.project_id
        try:
            initial_state, upstream = _single_node_input(
                node_id=args.node,
                project_output_dir=project_output_dir,
                packet_sha256=evidence_binding.reference.packet_sha256,
            )
            initialize_run_manifest(
                run_directory=run_output_dir,
                run_id=run_id,
                project_id=evidence_binding.packet.project_id,
                evidence_packet_ref=evidence_binding.reference.model_dump(mode="json"),
                text_model=_configured_text_model(),
                requested_node=args.node,
                rule_versions={
                    "scope": SCOPE_RULE_VERSION,
                    "retrieval_profile": PROFILE_VERSION,
                    "field_fact_prompt": FIELD_FACT_PROMPT_VERSION,
                },
                upstream=upstream,
            )
        except Exception as exc:
            logger.error("单节点运行准备失败: %s", exc)
            return 1
        graph = {"0": node0_graph, "1": node1_graph, "2": node2_graph}[args.node]
        completed_name = {"0": "define_scope", "1": "build_product_context", "2": "identify_assets"}[
            args.node
        ]
        expected_status = {
            "0": "node_0_completed",
            "1": "node_1_completed",
            "2": "asset_identification_completed",
        }[args.node]
        logger.info("启动单节点运行，node=%s，run_id=%s", args.node, run_id)
        result = _run_with_progress(
            graph,
            initial_state,
            config,
            run_output_dir,
            run_id,
        )
        status = str(result.get("status", "unknown"))
        try:
            manifest_path = record_node_result(
                run_directory=run_output_dir,
                node_id=args.node,
                status=status,
                completed_node=completed_name,
            )
        except Exception as exc:
            logger.error("运行清单写入失败: %s", exc)
            return 1
        _log_result(result)
        if status != expected_status:
            logger.error("Node %s 未完成，status=%s；清单=%s", args.node, status, manifest_path)
            return 1
        logger.info("Node %s JSON/Excel 已生成；待开发检查后登记可用: %s", args.node, manifest_path)
        return 0

    logger.info("启动工作流，模式=%s，run_id=%s", args.mode, run_id)
    result = _run_with_progress(
        tara_graph,
        {"errors": []},
        config,
        run_output_dir,
        run_id,
    )
    _log_result(result)

    if args.mode == "assets":
        if not result.get("__interrupt__"):
            logger.error("资产模式未到达 Node [2] 人工确认点；不生成审核包")
            return 1
        try:
            json_path, excel_path = export_asset_review(result, run_output_dir, run_id)
        except Exception as exc:
            logger.error("Node [0]-[2] 审核包导出失败: %s", exc)
            return 1
        logger.info("JSON 审核结果: %s", json_path)
        logger.info("Excel 审核结果: %s", excel_path)
        logger.info("工作流保持在 Node [2]；未批准资产，未执行 Node [3]")
        return 0

    result = _resume_asset_review(result, config)
    _log_result(result)
    if result.get("status") != "threat_modeling_completed":
        logger.warning("工作流未完成 Node [3]，不导出完整报告")
        return 1

    report_path = run_output_dir / "tara_report.xlsx"
    export_tara_report(result, str(report_path))
    logger.info("Node [0]-[3] 报告已导出: %s", report_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
