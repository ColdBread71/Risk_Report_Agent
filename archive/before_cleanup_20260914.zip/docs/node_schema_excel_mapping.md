# Node Schema 与 Excel 字段映射（当前实现）

版本：v1.1  
基线日期：2026-09-10  
适用范围：当前已实现的 Node [0]-[3]；重点用于审阅 Node [0]-[2] 第一版成果。

## 1. 先理解三层数据

| 层次 | 用途 | 是否是正式业务结果 | 保存位置 |
|---|---|---:|---|
| RAG 字段事实 | 针对一个小主题检索少量原文块，再提炼原子事实、未知项和矛盾 | 否，是 Node 的内部输入 | `progress/field_facts/node_x/*.json` |
| Pydantic Node Schema | 把多批字段事实综合成一个经过结构、语义和证据校验的 Node 结果 | 是 | `progress/node_x_*.json`、`node_0_2_review.json` |
| Excel 审阅视图 | 把正式 Schema 中适合人工检查的字段排成表格 | 是，但不是全部 JSON 字段的完整镜像 | `progress/*.xlsx`、`node_0_2_review.xlsx` |

当前 RAG 路径不是“一个小批次生成一列 Excel”。它先完成多个窄主题事实抽取，再由一次 Node 综合请求生成正式 Schema。只有通过校验的 Node 结果才进入 Excel。

`node_0_2_review.xlsx` 是资产批准前的审阅包，不是完整 TARA 报告。当前完整报告导出器只覆盖到 Node [3]；Node [4]-[8] 尚未进入可执行图，因此本文不为它们虚构字段或 Excel 映射。

### 1.1 语言规则

| 内容类型 | Excel 显示规则 |
|---|---|
| Sheet 名、标题、字段名、说明 | 使用简体中文 |
| 布尔值、完整性结论、常见资产/目标/功能类别 | 在展示层映射为中文 |
| 新生成的分析性叙述 | 使用简体中文 |
| 产品名、型号、协议、法规/标准编号、稳定 ID | 保留正式写法，不强制翻译 |
| `EvidenceRef.quote` 客户原文 | 保留原始语言，不翻译、不改写 |

旧 JSON 中已经生成的英文分析内容不会由展示层擅自翻译；重新执行 Node 综合后才会按新的中文生成规则输出。事后机器翻译可能改变含义或证据对应关系，因此不作为正式数据链路。

## 2. 当前工作流与 Excel 工作表

| 顺序 | 流程位置 | 正式输出 | Excel 工作表 |
|---:|---|---|---|
| 1 | Node [0] | `ScopeStatement` | `Node0 范围定界` |
| 2 | Node [1] | `ProductContext` | `Node1 产品概况`、`Node1 产品功能`、`Node1 组件清单`、`Node1 通信矩阵` |
| 3 | Node [2] | `AssetIdentificationResult` 拆入 State | `Node2 资产与目标` |
| 4 | Node [3] | `ThreatAssessment` | `Node3 STRIDE 威胁`；资产审阅模式不生成 |
| 5 | 支撑信息 | `RiskMethodology`、`RiskAcceptanceCriteria`、节点结论 | `方法与准则` |
| 6 | 支撑信息 | 各 Node 的 `EvidenceRef` | `证据追溯`，固定放在最后 |

所有工作表按“业务生成结果在前、方法和证据在后”排列。表格中的“仅 JSON”表示 Schema 中真实存在，但当前 Excel 审阅视图没有直接展示；这不代表字段未生成。

Excel 不允许 Sheet 名包含 `[` 或 `]`，所以实际页签使用 `Node0`、`Node1`、`Node2`、`Node3`。下文详细映射中的 `[0]`、`[1]`、`[2]`、`[3]` 是相同 Node 的业务简写，箭头末端的中文字段名均为 Excel 中的实际名称。

## 3. Node [0]：法律与产品范围

### 3.1 产品基础档案

| Schema 字段 | 业务含义 | Excel 对应 |
|---|---|---|
| `scope.product_name` | 客户材料中的正式产品名称，不允许推测或改名 | `[0] 范围定界` → `产品基础` → `产品名称` |
| `scope.product_version` | 产品、硬件或软件版本；材料未给出时为空 | `[0] 范围定界` → `产品基础` → `产品版本` |

### 3.2 CRA 身份与合规属性

| Schema 字段 | 业务含义 | Excel 对应 |
|---|---|---|
| `scope.classification.is_pde` | 是否属于 CRA 的 product with digital elements | `[0] 范围定界` → `CRA 属性` → `是否属于含数字元素产品（PDE）` |
| `scope.classification.classification` | `Default`、`Important` 或 `Critical`；证据不足时为空 | `[0] 范围定界` → `CRA 属性` → `产品分类` |
| `scope.classification.has_rdps` | 是否存在提供产品功能所需的远程数据处理解决方案 | `[0] 范围定界` → `CRA 属性` → `是否包含远程数据处理方案（RDPS）` |
| `scope.classification.rdps_description` | RDPS 运营方、交换数据、信任/认证关系和降级模式 | `[0] 范围定界` → `CRA 属性` → `远程数据处理方案说明` |
| `scope.classification.applicable_annex` | 有证据支持时记录适用的 CRA Annex III/IV | `[0] 范围定界` → `CRA 属性` → `适用附件` |
| `scope.classification.overlapping_regulations` | 可能叠加适用的其他欧盟法规 | `[0] 范围定界` → `CRA 属性` → `可能叠加的其他法规` |

### 3.3 评估范围边界

| Schema 字段 | 业务含义 | Excel 对应 |
|---|---|---|
| `scope.scope_description` | 本次评估覆盖的产品、数字组件、RDPS 和边界摘要 | `[0] 范围定界` → `评估边界` → `范围说明` |
| `scope.in_scope_components` | 纳入评估的组件、接口、服务和依赖 | `[0] 范围定界` → `评估边界` → `范围内组件、接口与服务` |
| `scope.out_of_scope_components` | 排除项及已知排除理由 | `[0] 范围定界` → `评估边界` → `范围外项目及理由` |

### 3.4 法律依据与假设

| Schema 字段 | 业务含义 | Excel 对应 |
|---|---|---|
| `scope.assumptions` | 界定范围所需、仍待客户确认的前提 | `[0] 范围定界` → `依据与假设` → `待确认假设` |
| `scope.legal_basis[]` | 结构化法规/标准依据：regulation、article、clause、annex 等 | `[0] 范围定界` → `依据与假设` → `法律与标准依据` |

### 3.5 结论、完整性与证据

| Schema 字段 | 业务含义 | Excel 对应 |
|---|---|---|
| `scope.evidence[]` | 支撑范围结论的真实文件、页码、章节、块和原文引用 | `证据追溯` |

Node [0] 当前通过 5 个内部检索主题准备事实：`product_identity`、`intended_purpose`、`scope_boundary`、`remote_services`、`classification_inputs`。它们不直接对应 Excel 列。

## 4. Node [1]：产品上下文、方法和接受准则

### 4.1 产品标识与 IPRFU

| Schema 字段 | 业务含义 | Excel 对应 |
|---|---|---|
| `product_context.product_name` | 与 Node [0] 保持一致的正式产品名 | `[1] 产品概况` → `产品基础` → `产品名称` |
| `product_context.product_version` | 产品版本；材料未给出时为空 | `[1] 产品概况` → `产品基础` → `产品版本` |
| `iprfu.intended_purpose` | 制造商声明的预期用途 | `[1] 产品概况` → `预期用途与可预见使用` → `预期用途` |
| `iprfu.reasonably_foreseeable_use` | 合理可预见使用或误用情景 | `[1] 产品概况` → `预期用途与可预见使用` → `合理可预见使用或误用` |
| `iprfu.health_safety_considerations` | 网络事件对健康、安全、财产、环境或公共利益的影响 | `[1] 产品概况` → `预期用途与可预见使用` → `健康与安全考虑` |
| `iprfu.accessibility_considerations` | 安全安装、认证、操作、维护或退役中的可访问性约束 | `[1] 产品概况` → `预期用途与可预见使用` → `可访问性考虑` |
| `iprfu.support_period` | 客户材料明确给出的支持期限或停止支持信息 | `[1] 产品概况` → `预期用途与可预见使用` → `支持期限` |
| `iprfu.evidence[]` | 上述结论的证据 | `证据追溯` |

### 4.2 用户描述

| Schema 字段 | 业务含义 | Excel 对应 |
|---|---|---|
| `user_description.user_types` | 最终用户、管理员、维护者、安装者、集成商等 | `[1] 产品概况` → `用户` → `用户类型` |
| `user_description.experience_level` | 预期网络安全知识、培训与操作能力 | `[1] 产品概况` → `用户` → `经验与能力` |
| `user_description.vulnerable_groups` | 有依据的弱势或无障碍相关群体 | `[1] 产品概况` → `用户` → `弱势或无障碍相关群体` |
| `user_description.is_component` | 产品是否作为组件集成到其他产品/系统 | `[1] 产品概况` → `用户` → `是否作为组件集成` |
| `user_description.rdps_dependence` | 用户或集成商对 RDPS 的依赖 | `[1] 产品概况` → `用户` → `用户对远程服务的依赖` |
| `user_description.responsibilities` | 客户材料明确分配给用户、运营方或集成商的责任 | `[1] 产品概况` → `用户` → `用户、运营方或集成商责任` |
| `user_description.evidence[]` | 上述结论的证据 | `证据追溯` |

### 4.3 运行环境

| Schema 字段 | 业务含义 | Excel 对应 |
|---|---|---|
| `operational_environment.description` | 产品部署和运行方式的总体描述 | `[1] 产品概况` → `运行环境` → `总体说明` |
| `networks` | 本地、工业、云、蜂窝、无线或互联网网络 | `[1] 产品概况` → `运行环境` → `相关网络` |
| `integrated_systems` | 与产品集成的设备、平台和服务 | `[1] 产品概况` → `运行环境` → `集成系统` |
| `physical_environment` | 室内外、环境暴露和物理访问条件 | `[1] 产品概况` → `运行环境` → `物理环境` |
| `network_boundaries` | 网络或信任边界及其接口/控制 | `[1] 产品概况` → `运行环境` → `网络与信任边界` |
| `constraints` | 连接性、可用性、安全、监管或第三方约束 | `[1] 产品概况` → `运行环境` → `运行约束` |
| `rdps_dependency_map` | RDPS 运营、数据交换、认证、可用性和降级模式摘要 | `[1] 产品概况` → `运行环境` → `远程服务依赖关系` |
| `evidence[]` | 上述结论的证据 | `证据追溯` |

### 4.4 产品功能

| Schema 字段 | 业务含义 | Excel 对应 |
|---|---|---|
| `functions[].function_id` | 当前上下文内唯一的功能 ID | `[1] 产品功能` → `功能编号` |
| `name` | 功能名称 | `[1] 产品功能` → `功能名称` |
| `function_category` | 数据采集、通信、配置、认证、更新、日志等类别 | `[1] 产品功能` → `功能类别` |
| `is_security_function` | 是否直接提供或强制执行网络安全保护 | `[1] 产品功能` → `是否安全功能` |
| `interfaces` | 该功能使用或暴露的接口 | `[1] 产品功能` → `相关接口` |
| `rdps_dependencies` | 该功能依赖的远程服务 | `[1] 产品功能` → `远程服务依赖` |
| `description` | 可观察行为、输入输出、用户和组件 | `[1] 产品功能` → `功能说明` |
| `limitations` | 已知限制、排除和使用条件 | `[1] 产品功能` → `限制与条件` |
| `evidence[]` | 功能证据 | `证据追溯` |

### 4.5 组件清单

| Schema 字段 | 业务含义 | Excel 对应 |
|---|---|---|
| `component_inventory.entries[].component_id` | 当前上下文内唯一的组件 ID | `[1] 组件清单` → `组件编号` |
| `name` | 组件名称 | `[1] 组件清单` → `组件名称` |
| `component_type` | 硬件、固件、软件、服务、库、操作系统等类型 | `[1] 组件清单` → `组件类型` |
| `role` | 组件在产品/安全功能中的作用 | `[1] 组件清单` → `作用` |
| `interfaces` | 与 TOE 或外部系统相连的接口 | `[1] 组件清单` → `相关接口` |
| `version`、`supplier`、`is_third_party`、`support_period` | 版本、供应方、第三方属性和支持期限 | `[1] 组件清单` → `版本或型号`、`供应方或运营方`、`是否第三方`、`支持期限` |
| `evidence[]` | 组件证据 | `证据追溯` |
| `component_inventory.completeness_notes` | SBOM、版本、供应方等清单缺口 | `[1] 产品概况` → `清单完整性` → `组件清单说明` |

### 4.6 通信矩阵

| Schema 字段 | 业务含义 | Excel 对应 |
|---|---|---|
| `communication_matrix.entries[].flow_id` | 唯一通信流 ID | `[1] 通信矩阵` → `通信流编号` |
| `source`、`destination` | 通信源与目的端 | `[1] 通信矩阵` → `源端`、`目的端` |
| `direction` | 入站、出站、双向等方向 | `[1] 通信矩阵` → `方向` |
| `interface` | Ethernet、RS485、USB、蜂窝、API、Web 等接口 | `[1] 通信矩阵` → `接口` |
| `protocol`、`port` | 有证据的协议与端口 | `[1] 通信矩阵` → `协议`、`端口` |
| `data_exchanged` | 交换的数据、命令、凭据、配置、遥测或更新 | `[1] 通信矩阵` → `交换数据` |
| `encryption` | 材料明确说明的加密机制和范围 | `[1] 通信矩阵` → `加密机制` |
| `authentication`、`security_notes` | 认证机制与通信安全观察 | `[1] 通信矩阵` → `认证机制`、`安全说明` |
| `evidence[]` | 通信流证据 | `证据追溯` |
| `communication_matrix.completeness_notes` | 缺失图纸、方向、协议等覆盖限制 | `[1] 产品概况` → `清单完整性` → `通信矩阵说明` |

### 4.7 汇总、完整性与证据

| Schema 字段 | 业务含义 | Excel 对应 |
|---|---|---|
| `existing_security_functions` | 客户材料已经证明存在的安全功能摘要 | `[1] 产品概况` → `已有能力` → `已有安全功能` |
| `existing_non_security_functions` | 已证明存在的普通产品功能摘要 | `[1] 产品概况` → `已有能力` → `已有非安全功能` |
| `rdps_dependencies` | 全部 RDPS 依赖的汇总 | `[1] 产品概况` → `已有能力` → `远程服务依赖汇总` |
| `assessment` | Product Context 完整性判决 | `[1] 产品概况` → `完整性结论` → `评估结论` |
| `assessment_notes` | Product Context 缺口和待确认事项 | `[1] 产品概况` → `完整性结论` → `结论说明` |
| `product_context.evidence[]` | Product Context 聚合层证据 | `证据追溯` |

### 4.8 固定风险方法

`RiskMethodology` 由 `core/policy.py` 确定性生成，不由模型自由决定。

| Schema 字段 | 业务含义 | Excel 对应 |
|---|---|---|
| `policy_version` | 当前方法规则版本 | `方法与准则` → `固定风险方法` → `规则版本` |
| `threat_modelling_method` | 固定为 STRIDE | `方法与准则` → `固定风险方法` → `威胁建模方法` |
| `risk_estimation_method` | 固定为 DREAD | `方法与准则` → `固定风险方法` → `风险估计方法` |
| `statutory_risk_factors`、`risk_combination_rule` | 法定因子 likelihood/magnitude 与组合规则 | `方法与准则` → `固定风险方法` → `法定风险因子`、`风险组合规则` |
| `likelihood_dimensions`、`magnitude_dimensions` | DREAD 五维如何分配到两类法定因子 | `方法与准则` → `固定风险方法` → `可能性维度`、`影响程度维度` |
| `damage_required_coverage` | Damage 必须考虑的安全、邻接设备/网络和规模化影响 | `方法与准则` → `固定风险方法` → `损害评估必查范围` |
| `risk_acceptance_rule`、`treatment_priority` | 默认不接受现存风险及 Avoid→Mitigate→Accept→Transfer 顺序 | `方法与准则` → `固定风险方法` → `风险接受规则`、`风险处置优先级` |
| `node_4_scale_status`、`source_references` | Node [4] 量表是否冻结及方法依据 | `方法与准则` → `固定风险方法` → `Node [4] 量表状态`、`方法依据` |

### 4.9 产品特定风险接受准则

| Schema 字段 | 业务含义 | Excel 对应 |
|---|---|---|
| `policy_version` | 必须与固定方法版本一致 | `方法与准则` → `产品特定接受准则` → `规则版本` |
| `regulatory_factors` | 与本产品相关的监管因素 | `方法与准则` → `产品特定接受准则` → `监管因素` |
| `contractual_factors` | 合同、客户或供应链责任因素；未知时为空 | `方法与准则` → `产品特定接受准则` → `合同与供应链因素` |
| `risk_nature_factors` | 已知风险性质 | `方法与准则` → `产品特定接受准则` → `风险性质因素` |
| `user_factors` | 用户类型和能力因素 | `方法与准则` → `产品特定接受准则` → `用户因素` |
| `product_factors` | 产品用途、环境、功能和依赖因素 | `方法与准则` → `产品特定接受准则` → `产品因素` |
| `state_of_art_factors` | 有依据的技术现状和社会价值因素 | `方法与准则` → `产品特定接受准则` → `技术现状与社会价值因素` |
| `aggregate_risk_considered` | 是否考虑风险聚合；必须为 true | `方法与准则` → `产品特定接受准则` → `是否考虑聚合风险` |
| `evidence[]` | 只能复用 Node [0]/[1] 已验证证据 | `证据追溯` |

Node [1] 当前通过 8 个内部检索主题准备事实：`iprfu`、`users`、`operational_environment`、`functions`、`components`、`communications`、`security_functions`、`rdps_dependencies`。它们不直接对应 Excel 列。

## 5. Node [2]：资产与网络安全目标

### 5.1 资产

| Schema 字段 | 业务含义 | Excel 对应 |
|---|---|---|
| `assets[].asset_id` | 当前资产清单内唯一且稳定的 `ASSET-xxx` | `[2] 资产与目标` → `资产编号` |
| `name` | 被保护价值对象的名称 | `[2] 资产与目标` → `资产名称` |
| `asset_type` | data、credential、software、hardware、network、service、function、user/property/environment 等 | `[2] 资产与目标` → `资产类型` |
| `location` | 资产存储、处理、运行或暴露的位置 | `[2] 资产与目标` → `所在位置` |
| `value` | 资产价值或受损后果 | `[2] 资产与目标` → `资产价值或受损后果` |
| `description` | 资产的边界、作用和受影响对象 | `[2] 资产与目标` → `资产说明` |
| `evidence[]` | 资产存在及其属性的证据 | `证据追溯` |

### 5.2 每项资产的网络安全目标

| Schema 字段 | 业务含义 | Excel 对应 |
|---|---|---|
| `related_objectives[].objective_id` | 全资产范围唯一且稳定的 `OBJ-xxx` | `[2] 资产与目标` → `目标编号` |
| `category` | confidentiality、integrity、availability、authenticity、accountability、data_minimization 等 | `[2] 资产与目标` → `目标类别` |
| `description` | 对该资产需要实现的、可验证的保护结果 | `[2] 资产与目标` → `网络安全目标` |
| `legal_basis[]` | 该目标对应的法规或标准依据 | `[2] 资产与目标` → `目标法律与标准依据` |
| `evidence[]` | 该目标的事实证据 | `证据追溯` |

同一资产有多个目标时，Excel 会为每个“资产—目标”关系各写一行，因此资产字段会重复。这是规范化的一对多展开，不是重复识别资产。

### 5.3 节点结论与审批状态

| State/Schema 字段 | 业务含义 | Excel 对应 |
|---|---|---|
| `asset_assessment` | 资产及目标覆盖完整性：PASS/PARTIAL/FAIL | `方法与准则` → `Node [2] 结论` → `资产识别完整性` |
| `asset_notes` | 缺失类别、证据不足和待复核内容 | `方法与准则` → `Node [2] 结论` → `资产识别说明` |
| `asset_review_approved` | 人工是否明确批准完整资产清单 | `方法与准则` → `Node [2] 人工审批` → `是否已批准` |
| `asset_review_notes` | 审批人的备注 | `方法与准则` → `Node [2] 人工审批` → `审批备注` |

Node [2] 当前通过 7 个内部检索主题准备事实：`data_assets`、`credentials_and_keys`、`software_and_configuration`、`hardware_and_network`、`external_services`、`function_assets`、`user_property_environment`。这些分组用于防止一次请求遗漏资产类别，不是七张业务表。

## 6. Node [3]：STRIDE 威胁场景（当前已实现但本轮未运行）

### 6.1 威胁场景

| Schema 字段 | 业务含义 | Excel 对应 |
|---|---|---|
| `threats[].threat_id` | 唯一且稳定的 `THREAT-xxx` | `[3] STRIDE 威胁` → `威胁编号` |
| `stride_category` | STRIDE 六类之一 | `[3] STRIDE 威胁` → `STRIDE 类别` |
| `title` | 威胁简短名称 | `[3] STRIDE 威胁` → `威胁名称` |
| `targeted_assets[]` | 目标资产；必须引用已批准的完整资产对象 | `[3] STRIDE 威胁` → `目标资产编号` |
| `compromised_objectives[]` | 被破坏目标；必须属于已批准资产 | `[3] STRIDE 威胁` → `受损安全目标编号` |
| `cause_of_compromise` | 目标被破坏的原因 | `[3] STRIDE 威胁` → `受损原因` |
| `threat_actor`、`attack_path` | 威胁来源、前提和攻击路径 | `[3] STRIDE 威胁` → `威胁来源或攻击者`、`攻击路径或前提` |
| `known_vulnerabilities` | 有依据的已知可利用漏洞 | `[3] STRIDE 威胁` → `已知可利用漏洞` |
| `description` | 完整威胁场景描述 | `[3] STRIDE 威胁` → `威胁场景说明` |
| `confidence` | 对场景的置信等级 | `[3] STRIDE 威胁` → `置信度` |
| `evidence[]` | 威胁场景证据 | `证据追溯` |

### 6.2 节点结论

| Schema 字段 | 业务含义 | Excel 对应 |
|---|---|---|
| `threat_assessment.assessment` | 已批准资产的威胁覆盖是否充分 | `方法与准则` → `Node [3] 结论` → `威胁覆盖完整性` |
| `threat_assessment.notes` | 覆盖缺口、未知路径和证据限制 | `方法与准则` → `Node [3] 结论` → `威胁建模说明` |
| `threat_assessment.scores` | 当前固定为空；DREAD 评分属于 Node [4] | 不导出 |

## 7. 证据追溯怎么读

| Excel 列 | 含义 |
|---|---|
| `证据编号` | 该条引用的标识，不等于资产或功能编号 |
| `用于哪些字段` | 引用被哪些 Schema 路径使用，例如 `assets[0].evidence[0]` |
| `文档编号` / `文本块编号` | 解析语料中的稳定文档和文本块标识 |
| `文件名` / `PDF 物理页码` / `文档印刷页码` / `章节路径` | 回到客户原始材料的位置锚点 |
| `原文引用` | 支撑结论的原文；不能匹配原块时系统会拒绝或丢弃 |
| `证据等级` / `置信度` | 证据强度与置信等级 |
| `检索方式` / `是否人工确认` / `备注` | 检索来源、是否人工确认及补充说明 |

证据包和证据追溯表的作用不是生成额外 TARA 内容，而是让审阅者能回答：“这个结论来自哪份客户文件的哪一页、哪一节、哪段原文？”

## 8. 当前人工审批实际行为

`--mode assets` 是本阶段默认模式：图运行到 Node [2] 后触发 LangGraph interrupt，程序导出 `node_0_2_review.json/.xlsx` 并正常退出。它不会弹出窗口，也不会让你在 Excel 里点击按钮；日志中的“未批准资产”只是说明系统刻意没有伪造人工决定。

`--mode full` 才会在支持交互的终端中打印资产并等待键盘输入。只有输入完全一致的大写 `APPROVE`，再填写可选备注，图才会恢复并进入 Node [3]。输入其他内容视为拒绝；终端不可交互时保持在审批点。

当前 checkpointer 是内存型，审批并不是跨进程、跨天的持久待办，也没有 Streamlit/网页审批界面。可恢复审批和审阅 UI 属于后续产品化工作。

## 9. 本阶段建议审阅顺序

1. 先看 `[0] 范围定界`：产品身份、CRA 属性和评估边界是否正确。
2. 再看 `[1] 产品概况` 及三个明细表：用途、用户、环境、功能、组件和通信是否忠于材料。
3. 再看 `[2] 资产与目标`：资产粒度是否合适，每项资产是否真有价值，每项目标是否明确可验证。
4. 然后看 `方法与准则`：理解生成所遵循的方法、完整性结论和人工审批状态。
5. 最后用 `证据追溯` 抽查关键结论能否回到正确文件、页码、章节和原文。
5. 业务同事认可并修正 Node [0]-[2] 后，再明确批准资产并开始 Node [3] 真实运行。

## 10. 实现依据

本映射按当前代码编写：`schemas/legal.py`、`schemas/product.py`、`schemas/methodology.py`、`schemas/risk.py`、`schemas/threat.py`、`core/state.py`、`nodes/context_builder.py`、`nodes/asset_threat_modeler.py`、`core/exporter.py`、`main.py`。业务流程顺序以根目录 `CRA_TARA_workflow_prEN40000.md` 为准。
# 2026-09-14 Node0 补充（优先于历史映射）

classification.has_rdps 支持 null，中文展示“待确认”；conditional_scope_components 展示“条件适用的组件、接口与服务”。Node0 不再包含模型自评和结论说明。进度输出保留独立节点 JSON/Excel、run-id 与生成时间。证据原文缺失时展示规范文本块并附补全说明；原文是否支持结论由人工评审。
