# Current State

Status: ACTIVE  
Plan: v0.5  
Current stage: Stage A - Real input to approved assets  
Completed batch: A2.4 Node [0]-[2] controlled RAG run and Chinese review workbook  
Current gate: business review of the A2.4 assets/objectives and evidence before Node [2] approval

## Full project target

Implement the complete workflow defined by `CRA_TARA_workflow_prEN40000.md`:

`[0] scope -> [1] context/method/criteria -> [2] assets -> HITL -> [3] STRIDE -> [4] DREAD -> [5] decision -> HITL -> [6] treatment/reassessment -> [7] residual risk/documents -> [8] Annex I matrix`

The current Node [0]-[2] priority is the first usable delivery slice, not the end of the project.

## Implemented

- Independent Node [0] Scope and Node [1] ProductContext extraction with Pydantic validation/retry.
- Node [1] emits an immutable RiskMethodology snapshot plus product-specific RiskAcceptanceCriteria.
- Node [2] AssetIdentificationResult with canonical asset/objective IDs.
- Mandatory Node [2] human-review interrupt.
- Node [3] STRIDE generation with strict foreign-key checks, verified offline.
- Current graph: `define_scope -> build_product_context -> identify_assets -> review_assets -> model_threats -> END`.
- CLI defaults to `--mode assets`, supplies the validated evidence-packet runtime configuration, and stops at the existing Node [2] interrupt without resuming it.
- Node [0]-[2] review output has a versioned JSON contract and an eight-sheet Chinese Excel view. Node [0] and Node [1] are separated; generated business results appear first, method/criteria follow, and deduplicated evidence trace is last.
- Node [2] EvidenceRef values must exactly reuse evidence already validated in Node [0]/[1].
- Evidence source metadata is now materialized deterministically from a model-selected packet block; the model cannot author file paths, hashes, pages, or section locations.
- The first real 阳光 EMU run is stored under `output/yangguang_emu/678d4226317f4e75901ccbce63951579/` and remains paused before Node [3].
- Excel export and logging for the existing Node [0]-[3] MVP.
- Deterministic PDF corpus with file hash, page, section, block, table, and validation metadata.
- Static evidence-packet lookup/materialization with source-addressable citations.
- Immutable EvidencePacketRef in LangGraph State without storing packet blocks or filesystem paths.
- Evidence-packet loader verifies packet, manifest, and current source-file hashes.
- Recursive citation validator rejects unknown blocks and mismatched file, hash, parser, page, section, or quote data.
- Every structured LLM call now performs a local token-budget preflight. Known model aliases use provider input limits with safety headroom; an explicit deployment override is supported. Oversized prompts are rejected before customer evidence is sent, with actionable budget details.
- LLM transport failures no longer trigger an unbound-response error during validation retry; the original provider failure remains visible.
- Strict retrieval profiles cover 20 Node [0]-[2] fields. Retrieval uses an approved-packet scope, metadata filters, cosine ranking, same-section neighbor expansion, intact-block token budgeting, and an auditable packet/trace pair.
- The persisted FAISS index identity binds the corpus manifest hash, parser version, approved scope-packet hash, embedding model/dimensions, and embedding-text version. Index and source hashes are revalidated on reuse.
- The real approved-scope index `IDX-6BB44D1996D16BD9` contains 1,041 blocks embedded with DashScope `text-embedding-v4` at 1,024 dimensions. Representative field retrievals were inspected; excluded corpus material remains outside the index.
- Node [0]-[2] now optionally execute 20 bounded field retrieval/fact-extraction calls followed by one synthesis per business node. Only compact validated facts reach synthesis, while canonical block identities remain available for citations.
- The RAG path is enabled explicitly with `--rag-index`; omitting it preserves the static evidence-packet path. Both paths retain the existing LangGraph topology and mandatory Node [2] interrupt.
- CLI graph execution now streams updates and atomically writes `progress/latest.json`, `progress/latest.xlsx`, and node-specific JSON/Excel snapshots after every completed or failed business node. Successful field facts are checkpointed individually and can be reused with the same explicit `--run-id`.
- Evidence canonicalization now completes the trusted EvidenceRef envelope when the model supplies a valid packet `block_id`, including deterministic source metadata and required evidence-level defaults. Validation errors are logged in full.
- 阳光 EMU corpus: 4 documents, 335 pages, 487 sections, 4,607 blocks, and 94 tables.
- Approved packet: EMU300A, cybersecurity, and selected Logger5000 evidence; Logger4000 applicability remains unresolved.

## Retained architecture

- R2 parsed blocks are reusable RAG embedding units.
- R3 EvidencePacket/SourceRef remains the shared boundary for manual selection and future retrieval.
- Customer material and regulatory/standard material must retain separate provenance domains.
- Expert workbooks remain external human references and never enter model input.
- Evaluation-only R4 schemas, adapter, configuration, and golden artifacts have been removed.

## A1.4 baseline findings

- Technical gates passed: no State errors, valid schemas and foreign keys, valid packet block references, Node [2] interrupt reached, and Node [3] was not executed.
- Output: PARTIAL Scope, PARTIAL ProductContext, PARTIAL asset assessment, 10 functions, 4 components, 10 communication flows, 10 assets, and 19 objectives.
- Evidence is over-concentrated: seven trace rows resolve to six unique blocks; five non-verbatim model quotes were discarded transparently.
- Several detailed claims cite broad or unrelated blocks even when a stronger block exists in the packet; per-field evidence precision is not yet acceptable.
- Expert-workbook comparison indicates missing or over-aggregated reset credentials, product identifiers, and function/security assets such as login, user management, update, remote maintenance, and secure communication.
- Static-packet execution took about 12 minutes; ProductContext and asset extraction dominate latency.
- The controlled RAG rerun completed with `qwen-plus` while reusing 20 validated field checkpoints from the same source/index scope. Node [0], Node [1], criteria, and Node [2] synthesis all completed; the review package contains 4 functions, 3 components, 12 communication flows, 7 assets, 13 related objectives, 43 evidence-trace entries, and no runtime errors.
- The A2.4 review package is stored under `output/yangguang_emu/a24-rag-qwenplus-v4-zh/`. It uses Chinese generated narrative while preserving source quotes, product identifiers, protocols, standards, and other proper nouns in their source form.
- Real-data Node [3] validation, Nodes [4]-[8], durable cross-process LangGraph checkpointing, UI, and final trace assembly are not started.

## Immediate next action

### 2026-09-14 工作电脑更新（优先于下方历史状态）

- 家中仅复制 repair plan；工作电脑起点没有该计划声称的 Node0 修复，且 docs/reviews/ 不存在。第一版对比报告缺失，不宣称已复现原报告。
- 已补单节点 --node 0/1/2、独立 JSON/中文 Excel、run_manifest 和已检查上游指针；现阶段仅验证 Node0，Node1/2 尚未真实验证。
- 已生成 node0-r2-qwenplus-20260914-01 和 node0-r3-qwenplus-20260914-02；均未通过业务检查，checked_usable=false，不得作为 Node1 上游。
- 第二次改善：光纤环网交换机保留选配，RDPS 可为未知，原文可见。但仍有引用章节标题代替表格、无依据的 MPLC/PLC 等同及合规推断、能力与启用状态混淆。不能交付为已通过评审结果。
- 新发现：v1 证据包 Node0 选择范围遗漏产品结构材料；v2 将已有产品结构选择加入 Node0，原 PDF 未变。v2 索引为 rag_index/yangguang_emu/IDX-3B116ADDF3BB03CC。
- 当前代码 scope v5 / field prompt 2.2 已去掉 Node0 自评字段和业务判决式校验；Prompt 保留交换机、RDPS、能力/启用及禁止无依据推断的反馈。每个 Node0 提取步骤最多尝试两次。尚未真实运行这一版本；旧输出原样保留。
- 按用户节省额度要求，后续真实运行交用户执行，命令和独立对比 prompt 见 node0_2_repair_plan.md。本轮没有可登记的 Node0；Node2 未批准，Node3 未运行。

1. Review the A2.4 Chinese workbook against customer material and the expert workbook, focusing on Scope, ProductContext, asset categories/granularity, objectives, unknowns, and citations.
2. Record accepted corrections to the Node [0]-[2] prompts, retrieval profiles, or presentation mapping without changing canonical Schema fields.
3. Do not approve assets or execute Node [3] until the business review passes.

## Hard constraints

- The trusted workflow document is the business source of truth.
- Node [1] freezes method and acceptance criteria before Node [3]/[4].
- Node [3] never runs without explicit Node [2] approval.
- Node [4] alone owns DREAD likelihood, magnitude, and combined risk.
- Node [5] has a mandatory human risk-review checkpoint.
- Node [6] Mitigate results require reassessment through Node [4]/[5].
- Every material conclusion must resolve to product evidence and/or legal-standard authority as appropriate.
